# Handoff: Star Wolf — Tactical Command Board

## Overview

Star Wolf is a paused-time tactical starship simulator for PC. The player is a captain commanding a single capital ship, viewing the battlespace through a **tactical command table on the ship's bridge** — a top-down plotting surface, not a cockpit view and not an exterior 3D camera.

Combat is fought with time paused. The player observes contacts, plots courses, configures mounts, designates targets, then commits everything at once by pressing EXECUTE, which resumes time. This "plan then commit" loop is the core verb of the game and the reason the board is laid out the way it is.

This handoff covers the **in-mission board**: the plotting surface, the two instrument rails, the targeting computer, the flight and order readouts, and the physical control row.

## About the Design Files

The files in this bundle are **design references created in HTML** — prototypes that demonstrate intended appearance and behaviour. They are **not production code to copy directly**.

The task is to recreate these designs inside the target codebase's existing environment, using its established patterns, rendering approach and libraries. For a PC game this most likely means a game engine's UI layer (Unity UI Toolkit / UGUI, Unreal UMG, Godot Control nodes) or a custom immediate-mode UI. Where no environment exists yet, choose the most appropriate one for the project and implement there.

Two specific translation notes:

- The plot surface in the prototype is built from absolutely-positioned DOM elements with CSS transforms. In an engine, this should be **data-driven**: contacts, rings, arcs and annotations rendered from the simulation's own entity list, not hand-placed.
- The brushed-metal frame is a **WebGL fragment shader** (source included, see Assets). It ports directly to any engine's shader language, or can be replaced with an authored texture.

## Fidelity

**High-fidelity.** Colours, typography, spacing, sizing and interaction behaviour are all final-intent and should be matched closely. Exact hex values, pixel measurements and font stacks are documented below.

Two exceptions, both explicitly placeholder:

1. **Ship hull silhouettes.** All hulls are drawn as a simple 10-point "sword" wedge via CSS `clip-path`. These are stand-ins for real hull art. Do not treat them as final.
2. **Asteroid field.** Drawn as scattered ellipses. Placeholder for real debris art.

## Canvas

Fixed design resolution **1920 × 1080**. All measurements below are in design pixels at that resolution. The layout is built to a **104px side margin** which every horizontal band shares — status bar, plot, order row and hardware row all span x104→x1816.

Vertical bands:

| Band | Y range | Height |
|---|---|---|
| Status bar | 26 → 88 | 62 |
| Plot well | 100 → 834 | 734 |
| Order row | 844 → 944 | 100 |
| Hardware row | 954 → 1058 | 104 |

The plot occupies roughly 68% of board height. This is deliberate — the table is the subject of the screen and everything else is subordinate.

---

## Design Tokens

### Colour — semantic, not decorative

The palette is a **coding system**. Colour states allegiance or condition; it is never applied for visual interest. A green number always means own-systems. Do not introduce new hues without extending this system.

| Token | Hex | Meaning |
|---|---|---|
| `hostile` | `#E04B3C` | Enemy tracks, threat vectors, hull breach, targeting computer |
| `friendly` | `#4A9FD8` | Own fighters, friendly craft, shield, comms, hangar |
| `own-systems` | `#8FC33A` | Fire arcs, reactor, alert-green, measurement annotations |
| `orders` | `#E8A33D` | Queued actions, pending commits, target brackets, own deployed assets |
| `orders-bright` | `#F0A020` | EXECUTE label, active interlocks, on-bearing state |
| `unclassified` | `#9B7FD4` | Unresolved returns, possible missiles |
| `sensor` | `#3FA9C9` | Range rings, scan envelopes, grid lines — sensor data only |
| `own-ship` | `#E8EDF0` | Own hull, heading vector, primary values |

### Surfaces

| Token | Hex | Use |
|---|---|---|
| `void` | `#0A0C0E` | Board base beneath the metal |
| `metal-lit` | `#33383E` | Frame gradient start (158°) |
| `metal-mid` | `#23282D` | Frame gradient middle |
| `metal-shadow` | `#101315` | Frame gradient end |
| `plot-glass` | `#0A1719` | Plot surface |
| `scope-glass` | `#0B0405` | Targeting scope surface |
| `panel-well` | `rgba(10,15,17,.86)` | Readout panel faces |
| `button-face` | `rgba(20,24,28,.6)` | Rail button faces (semi-transparent so metal grain reads through) |

### Text tiers

| Tier | Hex | Use |
|---|---|---|
| Primary | `#E8EDF0` | Values, titles |
| Secondary | `#C9D2D8` | Body, button labels |
| Tertiary | `#A8B2B9` | Callout data |
| Label | `#6E7B85` | Field labels |
| Disabled | `#5B666F` / `#4E5860` | Inactive |

### Typography

Two families only.

**Barlow Condensed** — weights 400, 500, 600. Titles, system names, button labels, track designators. Letter-spacing 0.09–0.16em. Sizes 13–34px.

**Share Tech Mono** — regular. *All* numerics, bearings, ranges, timers, field labels, grid ticks, stencils. Letter-spacing 0.06–0.28em. Sizes 8–25px.

Rules: labels are always uppercase; no italics; units are set at the same size as the number they follow, never shrunk; numerics never animate their digits — they snap.

### Geometry

- Base unit **4px**
- Radii: **7px** outer panels, **6px** wells and rails, **4–5px** buttons, **3px** inner fields
- Strokes: **1px** at 8–20% white for dividers, **1.5px** for icon linework, **2px** for locks and emphasis
- Panel gap **10–12px**
- Grid: **60.9 × 58.2px** minor cells at `rgba(63,169,201,.065)`

### Elevation and material

Every metal face carries a four-sided bevel:

```
box-shadow:
  inset  0  1px 0 rgba(255,255,255,.2),    /* lit top lip   */
  inset  0 -1px 0 rgba(0,0,0,.6),          /* shadowed base */
  inset  1px 0  0 rgba(255,255,255,.06),   /* left          */
  inset -1px 0  0 rgba(0,0,0,.4);          /* right         */
```

Rivets are 3–4px radial-gradient circles (`#99A3AB` → `#0F1214` at 72%) with `0 1px 1px rgba(0,0,0,.7)`. They appear at panel corners and rail ends only — never as decorative runs.

Wells are recessed with inner shadow, never a plain border: `inset 0 0 0 1px <tint>, inset 0 4px 26px rgba(0,0,0,.95)`.

---

## Screens / Views

There is one screen. It has seven regions.

### 1. Status bar

**Purpose:** ship condition at a glance, plus time state.

**Layout:** `x104→x1816, y26→y88`, height 62. Horizontal flex, `rgba(11,14,17,.9)`, 1px `rgba(255,255,255,.13)` border, 7px radius, bevel plus `inset 0 -8px 22px rgba(0,0,0,.55)`. Cells divided by single 1px hairlines at `rgba(255,255,255,.1)`; every cell is `flex-shrink:0` with `white-space:nowrap` so values never break mid-unit.

**Components, left to right:**

1. **Ship HUD** — 18px padding, 14px gap. A 26×52px hull silhouette (wedge clip-path, `rgba(232,237,240,.2)` fill, `rgba(232,237,240,.7)` 1px border, centreline at 35%), with a blinking 22%-wide `#E04B3C` damage bar at 12% from the prow. Beside it two stacked bars, each 104px wide: label 8px mono `#6E7B85`, value 11px mono, then a 5px track (`#07090A`, inset shadow) with a coloured fill and matching glow.
   - HULL — 87%, `#E8EDF0`
   - SHIELD — 62%, `#4A9FD8`
   - `SW-01` in 11px mono `#6E7B85`, bottom-aligned.
2. **ALERT** — label + `GREEN` at 19px mono `#8FC33A`.
3. **MISSION TIME** — label + `01:32:45` at 19px mono `#E8EDF0`.
4. **Spacer**, then **PAUSED chip** — 6px margin, 1px `#E8A33D` border, 5px radius, `rgba(232,163,61,.1)` fill. `PAUSED` at 18px/600 `#F0A020` over `PRESS PLAY TO EXECUTE` at 9px mono `#A8842F`.

**Note on hierarchy:** this bar was deliberately reduced from ten equal cells. Identity, condition and time state belong here; flight data moved to the order row. Resist re-adding cells — the bar's sparseness is what makes hull and shield readable.

### 2. Plot well — the hero

**Purpose:** the battlespace. Everything else on the board serves this.

**Layout:** `x104→x1816, y100→y834`. `#0A1719`, 6px radius, `inset 0 0 0 1px rgba(63,169,201,.16), inset 0 4px 22px rgba(0,0,0,.9), 0 0 0 6px rgba(0,0,0,.35)`, `overflow:hidden`.

**Structure — two scaling world layers plus a fixed chrome layer:**

- **World layer 1** — the grid. `inset:-50%`, `transform:scale(zoom)`. Two overlaid backgrounds at 60.9×58.2px.
- **Fixed chrome** — axis labels pinned to all four edges, 11px mono `#5B7278`, signed, in thousands of km: `−30 −20 0 +20 +30` horizontally, `+20 0 −20` vertically, with `X (1000 KM)` and `Y (1000 KM)` captions.
- **World layer 2** — every plotted object. `transform:scale(zoom)` and it defines `--lbl: 1/zoom`, which every text callout inside consumes as `transform:scale(var(--lbl))` so labels hold their size while geometry scales.

**Contents of world layer 2:**

| Element | Treatment |
|---|---|
| Sensor range ring | 492px, 1px dashed `rgba(63,169,201,.36)`, label `SENSOR RANGE / 18,000 km` inside top |
| Active scan ring | 300px, 1px dashed `rgba(63,169,201,.5)`, label `ACTIVE SCAN / 8,000 km` |
| PDC arc | 340px conic wedge from 42°, 70° wide, `rgba(143,195,58,.15)`, two 1px edge rays at `rgba(143,195,58,.45)`, label `PDC GROUP A / ARC 042° ±35° / RANGE 4,000 km` |
| Own ship | 34×76px wedge, `#E8EDF0`, `rotate(62deg)`, `drop-shadow(0 0 9px rgba(232,237,240,.5))` |
| Heading vector | 150px 1.5px `#E8EDF0` line at `rotate(-28deg)` with an 11px arrowhead at its tip |
| Own ship label | `STARWOLF` 16px/600, `SW-01` in `#4A9FD8`, `HDG 062°`, `V 1.84 km/s` |
| TRACK 07 | 22×56px wedge, `rgba(224,75,60,.28)` fill + `#E04B3C` border, `rotate(56deg)`, drifting 17s; dashed threat vector with arrowhead |
| CONTACT 17 | 13px `#E04B3C` diamond outline; history trail fading 0.75→0.16 |
| FTR-2 | Four 15×17px triangles, `rgba(74,159,216,.25)` fill + `#4A9FD8` border, drifting 21s; dashed vector |
| CONTACT 22 | 12px `#9B7FD4` circle outline; trail fading toward the marker |
| BC-01 | 15px `#E8A33D` diamond, filled; fine dashed order leader |
| Board point alpha | White `×` glyph + `BOARD / POINT ALPHA`; 300px dashed white transit line |
| Predicted position | 22×52px dashed ghost wedge at 14% opacity, breathing 4s, labelled `+45 s / PREDICTED POSITION` |
| Asteroid field | Seven ellipses `rgba(168,178,185,.22–.3)`, labelled with range |

**Bearing convention — critical.** Screen angle = bearing − 90°. Own hull, its heading vector and its `HDG` label must all derive from one bearing value. Three independent angles is a bug that reads as a broken plot.

**Ruler annotation** — visible only when the RULER tool is active. Replaces what was previously a separate readout pane; the measurement belongs on the grid. A 262px `#8FC33A` baseline at `rotate(-42deg)` with `0 0 8px` glow, endpoint rings, three 9px tick graduations at 64/128/192px, and inline data: `RNG 24,300 km / BRG 048.2° / ΔV +362 m/s / TOF 65.4 s` in 11px mono `#8FC33A` with a dark text-shadow for legibility over the grid.

**Marker vocabulary.** Glyph states class; colour states allegiance. A shape is never reused across two allegiances.

- Filled wedge — own ship
- Outlined wedge — classified hostile hull
- Diamond outline — unclassified hostile
- Triangle — friendly craft
- Filled diamond — own deployed asset
- Circle outline — unresolved return
- Dashed wedge — predicted position

Vector length encodes speed at a fixed scale: a 1.10 km/s destroyer draws a visibly shorter arrow than the 1.84 km/s player.

### 3. Left tool rail — plotting instruments

**Purpose:** the captain's own annotations. Scratch marks with no consequences.

**Layout:** `left:26px`, vertically centred on the plot midpoint (`top:467px; transform:translateY(-50%)`). Width 64, padding 6, gap 5. `rgba(22,26,30,.42)`, 1px `rgba(255,255,255,.1)`, 6px radius.

**Buttons:** seven identical 52×52 cells, 4px radius, `rgba(20,24,28,.6)` face, full bevel, two diagonal rivets. **Icons only, no text labels** — names live in `title` tooltips. Every glyph sits in the same **20×20 optical box** at 1.5px stroke in `#A8B2B9`.

POINT (crosshair with centre square) · LINE · RULER · COMPASS · ERASE · UNDO · CLEAR ALL (dashed)

**Active state:** 1px `rgba(232,237,240,.85)` outline, `inset 0 0 15px rgba(232,237,240,.14)`, and a 3px left bar in `#E8EDF0`.

### 4. Right systems rail — command

**Purpose:** ship systems. These have consequences.

Geometrically identical to the left rail — same 64px width, same 52px cells, same 5px gaps, same centring — mirrored to `right:26px`. **This symmetry matters**; the two rails must never drift apart in size or rhythm.

Six systems, each icon in its own system colour while faces stay neutral:

| System | Icon | Colour |
|---|---|---|
| TARGETING COMPUTER | Missile silhouette, nose up, tail fins | `#E04B3C` |
| SENSORS | Three concentric emitter arcs from lower-left | `#3FA9C9` |
| REACTOR | Atom — three ellipses at 0/60/−60°, glowing nucleus | `#8FC33A` |
| HANGAR | Small plane, top-down | `#4A9FD8` |
| ENGINEERING | Open-ended wrench, canted 38° | `#E8A33D` |
| COMMS | Traffic panel with three transmission waves | `#4A9FD8` |

**Open state** (targeting): 1px `#E04B3C` outline, inner glow, 3px left bar.

> **Design intent:** annotation tools and command buttons currently share one visual treatment. The intended end state is that instruments read lighter and unlit while command switchgear reads heavier and lights when armed — so that *illumination always means "this will do something."* Worth implementing if the engine's UI supports it cheaply.

### 5. Targeting computer — slide-out drawer

**Purpose:** weapon-first target designation. The player selects a mount, the plot reveals what that mount can reach, then a target is designated and the firing chain is completed.

**Layout:** `right:104px, top:100px`, 376 × 830. Outer clip container with `pointer-events:none`; inner panel `transform:translateX(0 | 376px)` with `transition: transform .42s cubic-bezier(.2,.85,.25,1), opacity .3s ease`. It **pulls out** from the rail rather than popping. Metal gradient face, 4 corner rivets, `-18px 0 50px rgba(0,0,0,.8)` shadow.

**Header:** `TARGETING COMPUTER` 16px/600 + active mount short code in 10px mono `#E04B3C`, `rgba(224,75,60,.07)` band, `×` to close.

#### 5a. The scope — front-facing periscope

A receding corridor rendered in perspective, on near-black `#0B0405` with a red-orange trace. **226px tall.**

- Container `perspective:820px`; inner layer `transform: rotateY(scopeYaw)` where yaw = −0.42 × (target bearing − scope bearing), clamped ±17°. This produces genuine wall parallax as the scope slews.
- **Eight transverse rungs** on floor and ceiling at depth fractions `0, .22, .40, .55, .68, .78, .86, .92`, insetting toward the vanishing point, opacity fading 0.9 → 0.24.
- **Eight wall rails** at the same depths, left and right.
- **Four corner rays** at ±42.6°, gradient `rgba(224,75,60,.78)` → `.14`.
- **No centre crosshair.** Bore sight is marked only by two short 11px ticks, top and bottom centre.
- **Target marker:** eight-segment amber corner box, 46×46, positioned at `calc(50% + offset × 5.2px)` clamped ±150px, with the track designator beneath. Visible while |offset| < 27°.
- **ON BEARING:** when |offset| ≤ 4°, a full-height `rgba(240,160,32,.55)` centre line and an `ON BEARING` caption appear.
- **Bearing tape**, 28px along the bottom: two repeating-gradient tick scales (24px minor, 48px major) whose `background-position-x` is driven by scope bearing, a fixed amber index at centre, the numeric bearing, a `SLEW ◀ DRAG ▶` hint, and a `SNAP TO TGT` button.
- **Convergence bar** above the tape showing range as a fraction of mount maximum.
- Corner captions: `MOUNT PERISCOPE` and `OFF AXIS <value>`.

**Slewing:** `mousedown` in the scope captures start X and bearing; `mousemove` on window applies `delta × 0.34` degrees; `mouseup` releases. Cursor `ew-resize`. **Slewing off-target drops the SOLUTION interlock** — the solution is only valid while on bearing.

#### 5b. Mount selection

Five rows, 26px tall, 3px radius, `rgba(22,26,30,.7)`. Name in 13px/500, max range in 10px mono. Selected row gets a 1px `#E04B3C` outline, inner glow and a 3px left bar.

| Mount | Arc centre | Half-arc | Max range | Loaded | Magazine | Payloads |
|---|---|---|---|---|---|---|
| RAILGUN TURRET A | 042° | ±80° | 30,000 km | 2 / 2 | 22 | SLUG, SABOT |
| RAILGUN TURRET B | 250° | ±80° | 30,000 km | 1 / 2 | 19 | SLUG, SABOT |
| PDC GROUP A | 042° | ±35° | 4,000 km | BELT | 2400 | FLECHETTE |
| PDC GROUP B | 200° | ±35° | 4,000 km | BELT | 2180 | FLECHETTE |
| MISSILE VLS | — | all-round | 40,000 km | 8 / 8 | 8 | HE, EMP, PENETRATOR |

#### 5c. Firing solution inputs

Three fields on `#080A0B` with 1px `rgba(255,255,255,.11)` borders:

- **RANGE km** — 15px mono value with ▲▼ steppers, ±100 km per press
- **BEARING** — 15px mono value with ▲▼ steppers, ±1° per press
- **PAYLOAD** — cycles through the mount's payload list on click, showing position and a ▶ affordance

All three seed from the designated target and carry a manual trim offset.

#### 5d. Interlocks — three skeuomorphic toggles

46 × 64px bezel plates, metal gradient, 4px radius, full bevel plus `0 3px 7px rgba(0,0,0,.7)`, two rivets, and a recessed 11px-inset slot at `#090B0C` with `inset 0 2px 5px rgba(0,0,0,.9)`.

The handle is a 16 × 24px bat lever that physically throws:
- **Off** — bottom of the slot, cool grey `#B9C2C9` → `#5C666E`, shadow cast upward
- **On** — top of the slot, amber `#F0A020` → `#8A5A10`, `0 0 14px rgba(240,160,32,.5)` glow, shadow cast downward

| Interlock | Sub-label | Precondition |
|---|---|---|
| GYRO SPIN | MOUNT STAB | none |
| SOLUTION | FEED MOUNT | **refuses to throw unless ON BEARING**; drops if the scope slews off |
| SAFETY | INTERLOCK | none |

#### 5e. FIRE

Dead by default: `rgba(224,75,60,.4)` text on a dark gradient. Requires **a designated target and all three interlocks up**. Live state overlays a 2px `#E04B3C` border, `rgba(224,75,60,.16)` fill, `0 0 26px` outer and `inset 0 0 26px` inner glow, brighter `#FF6A58` text, blinking at 0.9s. Firing replaces the face with a solid `#E04B3C` `ROUNDS AWAY` state.

A status line above states why FIRE is unavailable: `DESIGNATE A TARGET` → `THROW ALL THREE INTERLOCKS` → `SOLUTION LOCKED — MOUNT READY`.

### 6. Order row

`x104→x1816, y844→y944`, height 100, 10px gaps.

**FLIGHT** (flex 1.15) — neutral `rgba(255,255,255,.12)` border. Header 16px/600. Cells: HEADING `062°`, VELOCITY `1.84 km/s`, SIGNATURE `PASSIVE`, REACTOR `120 MW` with a six-bar green level meter. Footer line in 10px mono `#5B666F`: `THRUST 0.18 g · HEAT 67.6% · E-SIG 15`.

**NAVIGATION ORDER** (flex .9) — `rgba(232,163,61,.4)` border, header in `#E8A33D`. Cells: DESTINATION `NAV 03`, HEADING `083°`, BURN `14 s`, ACCELERATION `0.18 g` (highlighted `rgba(255,255,255,.05)`). `CANCEL ORDER` button.

**EXECUTE** (196px fixed, `box-sizing:border-box`) — 6px hazard-striped surround, `repeating-linear-gradient(45deg, #C8912F 0 11px, #1A1E22 11px 22px)`. Inner face gradient `#3A2A10 → #211707`, 1px `rgba(240,160,32,.6)`, inner amber glow. `EXECUTE` 25px/600 `#F0A020` over `RESUME TIME` 10px mono.

> Panels below the plot are bordered in the colour of the tool or system that owns them — green for measurement, amber for orders, neutral for passive readouts.

### 7. Hardware row — physical controls

`x104→x1816, bottom:22px`, height 104, 10px gaps. Faces are `rgba(22,26,30,.5)` so the metal grain reads through, 9px radius, bevel, `0 10px 26px rgba(0,0,0,.6)`.

**Group 1 — POWER / DISPLAY BRIGHTNESS / GRID SCALE.** Three columns sharing a top baseline (`align-items:stretch` on the parent, `align-self:flex-start` on each column — they have unequal content heights and must not centre independently).
- POWER: 17px `#8FC33A` square lamp, 13px glow, breathing 3.4s, + `SYSTEM ON`
- DISPLAY BRIGHTNESS: 48px knob
- GRID SCALE: 48px knob whose pointer angle is driven by live zoom, plus −/value/+ controls

**Knob construction:** `radial-gradient(circle at 36% 28%, #464C52, #131619 74%)`, `inset 0 0 0 1px rgba(255,255,255,.17)`, `0 4px 10px rgba(0,0,0,.8)`, and a single 2px `#D8DFE4` pointer with `transform-origin:50% 100%`. Detent labels sit beside the knob, never on a ring around it.

**Group 2 — TIME CONTROL.** Five raised keys: `−10s −1s PAUSE +1s +10s`. Neutral keys `linear-gradient(158deg,#363B41,#191D21)`; PAUSE is amber `#5C4113 → #3A280B` with a `rgba(240,160,32,.55)` border and glow. Four rivets each.

**Group 3 — PLAY RATE.** 52px knob with detent labels `x0.25 x1 x5 x10`.

**Group 4 — EMERGENCY ABORT** (222px). A 48×62px guarded switch: base plate plus a red cover `linear-gradient(158deg,#E24A3B,#8A231A)` with a highlight lip and a hinge line.

> Only two controls on the board are guarded: EMERGENCY ABORT and EXECUTE. Guarding is reserved for destructive or irreversible actions.

### 8. Industrial layer

A texture layer between the metal and the panels, `pointer-events:none`, confined entirely to frame gutters so it never competes with the plot. All elements 20–26% opacity — present when looked for, invisible when reading data.

- **Left gutter:** conduit bundle of three cables (5/4/3px, `linear-gradient(90deg, #0C0E10, #2E343A 42%, #0A0C0E)`) with an elbow bend, two clamp blocks, a vent louvre group, `BUS A-14` stencil, two bolts
- **Mid band** (between order and hardware rows): 1160px harness run with three clamps, an elbow, a vent louvre group, and `CONSOLE HARNESS — DO NOT SERVICE UNDER LOAD` / `VENT — PLENUM 3` stencils
- **Right gutter:** access hatch, `ACC 07`
- **Frame stencils:** `TCB-1 / REV D`, `CL II EQUIP — 480V DC`

Stencils are 8px at ~22% opacity — **texture only, unreadable by design.** Nothing may depend on reading them.

---

## Interactions & Behavior

### Grid zoom
- **Scroll wheel** over the plot: `zoom × 1.12` per notch up, `÷ 1.12` down. Clamped **0.5 → 3.0**, rounded to 2dp.
- Both world layers scale together. The `--lbl` counter-scale keeps all text at constant size.
- The GRID SCALE knob pointer reflects zoom logarithmically: `-140° + (ln(zoom/0.5) / ln 6) × 280°`.
- `preventDefault` on wheel so the page never scrolls.

### Tool selection
Click sets the active tool. Exactly one active at a time. Selecting RULER reveals the on-grid measurement annotation.

### Targeting chain
1. Click the targeting icon → drawer slides out (0.42s).
2. Select a mount → **valid target set recomputes immediately**. A hostile is valid when `range ≤ mount.range` **and** `angularDifference(track.bearing, mount.arcCentre) ≤ mount.halfArc`. Valid hostiles gain amber corner brackets on the plot; the panel reports `n IN ENVELOPE`.
3. Click a bracketed contact → designated. A 56px `#E04B3C` ring plus `LOCK` label appear on the plot; the panel fills in range and bearing. **Clicks on non-valid contacts are ignored.**
4. Slew the scope to within 4° → `ON BEARING`.
5. Throw all three interlocks. SOLUTION requires ON BEARING.
6. FIRE → `ROUNDS AWAY`.

**Resets:** changing mount clears target, payload index, trim and all interlocks. Changing target clears trim and interlocks. Slewing off-bearing clears SOLUTION only.

**Zero-envelope is a legitimate state,** not an error — PDC at 4,000 km reaches nothing in the current scenario. It tells the player to manoeuvre. But **the default mount on load must have at least one valid target**, or the feature reads as broken on arrival.

### Animation inventory

| Name | Duration | Easing | Applied to |
|---|---|---|---|
| `blink` | 1.0–1.3s | `steps(1)` | Hull breach, alerts, live FIRE |
| `breathe` | 2.2–3.4s | ease-in-out | Charging lamps, power lamp |
| `drift-a` | 17s | ease-in-out | TRACK 07 |
| `drift-b` | 21s | ease-in-out | FTR-2 wing |
| `ghost` | 4s | ease-in-out | Predicted position |
| `scan` | 1.8s | `steps(4)` | Plot scanline overlay |
| Drawer | 0.42s | `cubic-bezier(.2,.85,.25,1)` | Targeting computer |

---

## State Management

```
zoom          number   0.5–3.0, default 1
tool          enum     POINT | LINE | RULER | COMPASS | ERASE | UNDO | CLEAR
weaponsOpen   bool     targeting drawer
mount         enum     RGA | RGB | PDA | PDB | VLS
target        id|null  designated track
scopeBrg      number   0–360, periscope bearing
sw            { pwr, sol, sfy: bool }
payloadIdx    number   index into mount.payloads
trim          { range, bearing: number }   manual offsets
fired         bool
```

**Derived:** `validSet` (mount arc ∩ range ∩ hostile), `offBearing`, `onBearing` (|off| ≤ 4°), `allSet` (target ∧ all three switches), `scopeYaw`, `tgtX`.

**Data the simulation must supply per track:** id, display name, class, bearing, range, allegiance, speed, hull/section damage, scan confidence, predicted position at +t.

---

## Assets

- **`steel.png`** — 1920×1080 baked brushed-metal plate, generated from the shader below. Use if shaders aren't available.
- **`steel-plate.html`** — standalone renderer containing the full GLSL fragment shader. Anisotropic noise stretched along X for brush grain, a broad sheen from upper-left, two highlight bands, sparse scratches, plate vignette. Port directly or re-bake at other resolutions.
  - **Important:** the WebGL context must be created with `preserveDrawingBuffer: true, alpha: false`, or the buffer is discarded after compositing and the plate reads blank on export and after context loss. Repaint on `webglcontextrestored`.
- **Fonts** — Barlow Condensed and Share Tech Mono, both Google Fonts, SIL Open Font License. Bundle locally for a shipped game.
- **No raster art.** Every icon, hull and instrument is drawn in CSS. Hull silhouettes and asteroids are placeholders awaiting real art.

---

## Files

| File | What it is |
|---|---|
| `Star Wolf Board Live.dc.html` | **Primary reference.** The full interactive board — zoom, tool selection, targeting chain, periscope slewing. |
| `Star Wolf Board.dc.html` | Static predecessor. Useful for reading layout without interaction code. |
| `Star Wolf Asset Kit.dc.html` | **Read this second.** Component catalogue: colour system, type, frame construction, plot chrome, marker glyphs, callouts, controls, readouts, hardware. The normative spec for anything not covered above. |
| `Star Wolf Icons.dc.html` | Icon candidates with the chosen set, shown large and at 20px in situ. |
| `figma/steel-plate.html` | Brushed-metal shader source. |
| `figma/steel.png` | Baked metal plate. |

**Suggested reading order:** this README → `Star Wolf Asset Kit.dc.html` for the system → `Star Wolf Board Live.dc.html` for the assembly and behaviour.

---

## Open items

Known-incomplete, in priority order:

1. **Hull art.** All silhouettes are placeholder wedges. Real hulls need two tiers: a detailed version for inspect and hangar views, and a separately-drawn 12–20 point glyph legible at 30px on the plot — not an automatic reduction of the detailed one.
2. **HANGAR panel.** Rail icon exists; the panel does not. Should hold Starfighters and Assault Boats, using the same drawer behaviour as the targeting computer.
3. **SENSORS, REACTOR, ENGINEERING, COMMS panels.** Icons only so far.
4. **Two-tier contact labels.** All callouts currently carry a full data stack at equal weight. Intended: selected and threatening contacts show the full stack; everything else shows designator plus range until hovered or selected. **This is the largest remaining legibility win** and matters more as contact count grows.
5. **Delta channel.** In a paused-time game the question at unpause is "what changed while I wasn't looking," and nothing answers it. New contacts should flag until acknowledged; changed status values should carry a delta.
6. **Growable order queue.** One navigation order panel holds one order. Four queued orders have nowhere to go.
7. **Annotation vs command distinction.** See the systems rail note above.
